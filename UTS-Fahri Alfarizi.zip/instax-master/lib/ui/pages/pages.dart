import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:instax/model/barang_model.dart';
import 'package:instax/shared/shared.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:instax/ui/widget/widget.dart';
import 'package:supercharged/supercharged.dart';
part 'splash_page.dart';
part 'home_page.dart';
part 'detail_barang_page.dart';