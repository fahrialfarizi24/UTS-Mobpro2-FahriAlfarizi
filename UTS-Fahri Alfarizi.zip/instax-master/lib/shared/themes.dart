part of 'shared.dart';

Color mint = "70b1a1".toColor();
Color blue = "77a0c6".toColor();
Color choral = "b0463c".toColor();
Color lavender = "855f8c".toColor();
Color pink = "F3D9DD".toColor();
Color background = "F6F6F6".toColor();
Color gray = "ADADAD".toColor();
Color white = Colors.white;


TextStyle regular = GoogleFonts.poppins(fontSize: 13.sp);
TextStyle semibold = GoogleFonts.poppins(fontSize: 14.sp, fontWeight: FontWeight.w600);
TextStyle price = GoogleFonts.poppins(fontSize: 18.sp, fontWeight: FontWeight.w600);


